/*
 * AHNAF GRAPHI website
 * 1) Replace WHATSAPP_NUMBER with your business WhatsApp number.
 * 2) Add your real portfolio image URLs in portfolioItems.
 * 3) Supabase is optional for this public landing page. Keep secret/service_role keys
 *    out of browser files. Use only a publishable/anon key with correct RLS policies.
 */
const WHATSAPP_NUMBER = ""; // Example: "8801XXXXXXXXX" (digits only)

const portfolioItems = [
  { title: "মৃত্যু স্মরণিকা", label: "MEMORIAL DESIGN", style: "" },
  { title: "ইসলামিক ওয়াল আর্ট", label: "ISLAMIC DESIGN", style: "alt" },
  { title: "নিকাহনামা", label: "NIKAHNAMA", style: "light" },
  { title: "ইভেন্ট ব্যানার", label: "EVENT BANNER", style: "alt" },
  { title: "বিশেষ প্রকাশনা", label: "PUBLICATION", style: "" },
  { title: "কাস্টম ডিজাইন", label: "CUSTOM DESIGN", style: "light" }
];

const portfolioGrid = document.getElementById("portfolioGrid");
if (portfolioGrid) {
  portfolioGrid.innerHTML = portfolioItems.map(item => `
    <article class="portfolio-item">
      <div class="portfolio-thumb ${item.style || ""}">${escapeHTML(item.label)}</div>
      <h3>${escapeHTML(item.title)}</h3>
    </article>
  `).join("");
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[char]));
}

// Mobile navigation
const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");
menuToggle?.addEventListener("click", () => mainNav?.classList.toggle("open"));
mainNav?.querySelectorAll("a").forEach(link => {
  link.addEventListener("click", () => mainNav.classList.remove("open"));
});

// Bangla / English language toggle
let currentLanguage = "bn";
const languageToggle = document.getElementById("languageToggle");
languageToggle?.addEventListener("click", () => {
  currentLanguage = currentLanguage === "bn" ? "en" : "bn";
  document.documentElement.lang = currentLanguage;
  document.querySelectorAll("[data-bn][data-en]").forEach(element => {
    element.innerHTML = element.dataset[currentLanguage];
  });
  languageToggle.textContent = currentLanguage === "bn" ? "EN" : "বাংলা";
});

// WhatsApp order form
const orderForm = document.getElementById("orderForm");
orderForm?.addEventListener("submit", event => {
  event.preventDefault();
  const data = new FormData(orderForm);
  const message = [
    "আসসালামু আলাইকুম, AHNAF GRAPHI-তে একটি অর্ডার করতে চাই।",
    `নাম: ${data.get("name")}`,
    `মোবাইল: ${data.get("phone")}`,
    `ডিজাইন: ${data.get("service")}`,
    `বিস্তারিত: ${data.get("details") || "উল্লেখ নেই"}`
  ].join("\n");

  const note = document.getElementById("formMessage");
  if (!WHATSAPP_NUMBER) {
    if (note) note.textContent = "অর্ডার চালু করতে script.js ফাইলে WHATSAPP_NUMBER বসান।";
    return;
  }
  const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
  window.open(url, "_blank", "noopener,noreferrer");
});

document.getElementById("year").textContent = new Date().getFullYear();

/*
 * Supabase setup note:
 * Put your public Project URL and publishable/anon key in a separate config.js
 * and load it before this file only if your app needs Supabase on this page.
 * Never place service_role / secret keys in frontend JavaScript.
 */
