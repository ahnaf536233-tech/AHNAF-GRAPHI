// অর্ডার জমা: ব্রাউজার থেকে সরাসরি insert নেই। এই ফাংশন সার্ভারে যাচাই করে service role দিয়ে লেখে।
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";
const ORIGINS = (Deno.env.get("ALLOWED_ORIGINS") ?? "").split(",").map(s => s.trim()).filter(Boolean);
const cors = (o: string | null) => ({
  "Access-Control-Allow-Origin": o && ORIGINS.includes(o) ? o : (ORIGINS[0] ?? "null"),
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Access-Control-Allow-Methods": "POST, OPTIONS", "Vary": "Origin" });
const json = (b: unknown, s: number, h: HeadersInit) => new Response(JSON.stringify(b), {status: s, headers: {...h, "Content-Type": "application/json"}});
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

Deno.serve(async (req) => {
  const origin = req.headers.get("origin"), h = cors(origin);
  if (req.method === "OPTIONS") return new Response("ok", {headers: h});
  if (req.method !== "POST") return json({error: "Method not allowed"}, 405, h);
  if (ORIGINS.length && (!origin || !ORIGINS.includes(origin))) return json({error: "Origin not allowed"}, 403, h);
  let b: Record<string, unknown>;
  try { b = await req.json(); } catch { return json({error: "Invalid JSON"}, 400, h); }
  if (b.website) return json({ok: true}, 200, h); // honeypot
  const s = (v: unknown, max: number) => typeof v === "string" ? v.trim().slice(0, max) : "";
  const name = s(b.name, 100), contact = s(b.contact, 100), requirements = s(b.requirements, 2000);
  const deadline = s(b.deadline, 10), ref = s(b.reference_url, 500), serviceId = s(b.service_id, 36);
  if (name.length < 2) return json({error: "নাম লিখুন"}, 400, h);
  if (contact.length < 5 || !(/^[+\d][\d\s-]{7,}$/.test(contact) || /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(contact))) return json({error: "সঠিক মোবাইল নম্বর বা ইমেইল দিন"}, 400, h);
  if (requirements.length < 5) return json({error: "ডিজাইনের চাহিদা লিখুন"}, 400, h);
  if (deadline && (!/^\d{4}-\d{2}-\d{2}$/.test(deadline) || isNaN(Date.parse(deadline)))) return json({error: "তারিখ সঠিক নয়"}, 400, h);
  if (ref && !/^https:\/\/\S+$/.test(ref)) return json({error: "রেফারেন্স লিংক https:// দিয়ে শুরু হতে হবে"}, 400, h);
  if (serviceId && !UUID.test(serviceId)) return json({error: "সার্ভিস সঠিক নয়"}, 400, h);
  const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {auth: {persistSession: false}});
  const hour = new Date(Date.now() - 3600e3).toISOString(), ten = new Date(Date.now() - 600e3).toISOString();
  const [{count: c1}, {count: c2}] = await Promise.all([
    db.from("orders").select("id", {count: "exact", head: true}).eq("contact", contact).gte("created_at", hour),
    db.from("orders").select("id", {count: "exact", head: true}).gte("created_at", ten)]);
  if ((c1 ?? 0) >= 3 || (c2 ?? 0) >= 50) return json({error: "অনেক বেশি অনুরোধ; কিছুক্ষণ পরে আবার চেষ্টা করুন"}, 429, h);
  let sid: string | null = null, sname: string | null = null;
  if (serviceId) {
    const {data} = await db.from("services").select("id,name_bn").eq("id", serviceId).eq("published", true).maybeSingle();
    if (!data) return json({error: "সার্ভিসটি পাওয়া যায়নি"}, 400, h);
    sid = data.id; sname = data.name_bn;
  }
  const {data, error} = await db.from("orders").insert({name, contact, requirements, service_id: sid, service_name: sname, deadline: deadline || null, reference_url: ref || null}).select("id").single();
  if (error) { console.error("order insert failed", error.code); return json({error: "অর্ডার সংরক্ষণ করা যায়নি"}, 500, h); }
  return json({ok: true, id: data.id}, 200, h);
});
